This folder is for the configuration files for `availity-workflow` and `availity-ekko`.  Client-side configuration belongs in the `project/app` folder.
