import { availity, availityUi, availityConfig } from 'availity-angular';
import uiRouter from 'angular-ui-router';
import shims from 'angular-shims-placeholder';
import app from 'app-module';

import './app-component';
import './dashboard';
import './setpreference';

app
  .addModules([
    availity,
    availityUi,
    availityConfig,
    uiRouter,
    shims
  ])
  .config(($urlRouterProvider, $stateProvider) => {

    $stateProvider
      .state('app', {
        template: '<app></app>'
      });

    $urlRouterProvider.otherwise('/dashboard');

  });

export default app;
