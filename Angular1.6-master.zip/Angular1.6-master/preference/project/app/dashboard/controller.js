import './dashboard';

class DashboardController {

  constructor(dashboard, $stateParams) {

    const vm = this;

    if ( $stateParams.taskTodo === 'reset') {
      dashboard.init().then(() => {
        vm.dashboard = dashboard;
      });
    } else {
      dashboard.getPreferences();
      vm.dashboard = dashboard;
    }

  }

}

export default DashboardController;


