import uiRouter from 'angular-ui-router';
import { availity } from 'availity-angular';
import app from 'app-module';

import DashboardController from './controller';
import { request } from '../validation';
import body from './body.htm';
import './components';
import { footer, header } from '../common';

const config = function($stateProvider, avValProvider) {

  $stateProvider
    .state('app.dashboard', {
      url: '^/dashboard',
      params: {
        taskTodo: 'reset'
      },
      data: {
        title: 'Preference Center',
        logoURL: './images/ABCBS.png'
      },
      views: {
        'header': {
          template: header,
          controller($state) {
            this.title = $state.current.data.title;
          },
          controllerAs: 'vm'
        },
        'body': {
          template: body,
          controller: DashboardController,
          controllerAs: 'vm'
        },
        'footer': {
          template: footer
        }
      }
    });

  avValProvider.addRules({
    request
  });

};

app
  .addModules([uiRouter, availity])
  .config(config);

export default app;
