import app from 'app-module';

import learningCenter from './learningCenter';
import existingpref from './existingpref';


app
  .directive('learningSection', learningCenter)
.directive('existingprefSection', existingpref);

export default app;

