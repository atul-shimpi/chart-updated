import template from './existingpref.htm';
import '../../fooTable/FooTable-3/compiled/css/bootstrap.css';
import '../../fooTable/FooTable-3/compiled/footable.bootstrap.min.css';
import '../../fooTable/FooTable-3/compiled/footable.core';
import '../../fooTable/FooTable-3/compiled/footable.sorting';
import '../../fooTable/FooTable-3/compiled/footable.filtering';
import '../../fooTable/FooTable-3/compiled/footable.paging';
import '../../fooTable/FooTable-3/compiled/footable.editing';
/* import 'jquery';
import 'https://cdnjs.cloudflare.com/ajax/libs/jquery-footable/3.0.0/css/footable.bootstrap.min.css';
import 'https://cdnjs.cloudflare.com/ajax/libs/jquery-footable/3.0.0/js/footable.core.js';
import 'https://cdnjs.cloudflare.com/ajax/libs/jquery-footable/3.0.0/js/footable.filtering.js';
import 'https://cdnjs.cloudflare.com/ajax/libs/jquery-footable/3.0.0/js/footable.paging.js';
import 'https://cdnjs.cloudflare.com/ajax/libs/jquery-footable/3.0.0/js/footable.sorting.js'; */


const existingpref = {
  replace: true,
  template
};

export default function() {
  return existingpref;
}
