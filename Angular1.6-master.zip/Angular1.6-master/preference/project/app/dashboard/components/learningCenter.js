import template from './learningCenter.htm';

const learningCenter = {
  replace: true,
  template
};

export default function() {
  return learningCenter;
}
