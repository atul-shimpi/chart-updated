import app from 'app-module';
import { availity } from 'availity-angular';
import jQuery from 'jquery';
import uiRouter from 'angular-ui-router';
import '../common/apis/api-existing-pref';
import ExisClm from './prefConfig/footable_Columns.json';
import moment from 'moment';

class Dashboard {

  constructor(avOrganizationsResource, $state, avUsersResource, preferenceResource) {

    this.di = { avOrganizationsResource, $state, avUsersResource, preferenceResource};
    this.showLearningCenterTab = true;
    this.showExistingTab = false;
    this.organizations = null;
    this.selectedOrganization = null;
    this.isExistingPref = false;
    this.selectedPrefType = null;
    this.numOfExPref = 0;
    this.defaultPrefType = {
      'alerts': [
        {
          'id': '1',
          'name': 'ADT Notification'
        },
        {
          'id': '2',
          'name': 'Email Notification'
        }
      ]
    };
    this.orgnizationDetails = null;
    this.taxIds = [];
  }

  init() {
    this.selectedOrganization = null;
    this.selectedPrefType = null;
    this.showLearningCenterTab = true;
    this.showExistingTab = false;
    return this.getOrganizations().then(() => this);
  }

  selectTab(optionForTab) {
    if ( optionForTab === '1' ) {
      this.showExistingTab = true;
      this.showLearningCenterTab = false;
      jQuery('#exisTab').tab('show');
    }
    if (optionForTab === '2' ) {
      this.showLearningCenterTab = true;
      this.showExistingTab = false;
      jQuery('#learnTab').tab('show');
    }
  }
  queryOrganizations() {

    const self = this;

    return this.di.avOrganizationsResource
      .getOrganizations()
      .then(organizations => {
      // cache organizations
        self.organizations = organizations;
        return organizations;
      });

  }
  getOrganizationDetail = function() {
    const self = this;
    const successCallback = function(response) {
      self.organizationDetails = response.data;
      self.populateTaxID();
    };
    const errorCallback = function() {
      // $log.error(error);
    };
    this.di.avOrganizationsResource.get(this.selectedOrganization.id).then(successCallback, errorCallback);
  }
  // populate TAX ID's
  populateTaxID = function() {
    this.taxIds = this.organizationDetails.taxIds;
  }

  getOrganizations() {

    // The :: syntax below is proposed for ES7.  It is equivalent to the following code:
    //
    //    this.getUser().then(this.queryOrganizations.bind(this));
    //
    // Feel free to use either version that suits your coding style.
    //
    return this.getUser()
      .then(::this.queryOrganizations);

  }
  getUser() {

    const self = this;

    return this.di.
    avUsersResource
      .me()
      .then(user => {
      // cache user
        self.user = user;
        return user;
      });
  }
  onSubmit() {

    return this.di.$state.go('app.setpreference', {}, { location: false });

  }

  getPreferences() {
    this.selectTab('1');
    /* this.di.preferenceResource
     .query({
     }).then(response => {
     const exisPref = response.data;
     const $j = jQuery.noConflict();
     let exisRow = [];
     const rowCount = exisPref.levelone.length;
     const levelOne = [];
     let i = 0;
     const imageDiv = document.createElement('span');
     /!* imageDiv.innerHTML = "<a href='' class="+ "icon icon-trash-empty" + "></a>"; *!/
     // imageDiv.className ="icon icon-trash-empty";
     imageDiv.setAttribute('class', 'icon icon-trash-empty');
     // imageDiv.innerHTML ="<class="+ "icon icon-trash-empty"+" />";
     // imageDiv.src = "../images/delete.png";
     // let eleme = document.createElement('span');
     // div.innerHTML = document.getElementById('blockOfStuff').innerHTML;
     // document.getElementsByName('delIcon').appendChild(eleme);
     for (i = 0; i < rowCount; i++) {
     const rowData = {};
     rowData.modifiedBy = exisPref.levelone[i].modifiedby;
     rowData.modifiedOn = exisPref.levelone[i].modifiedon;
     rowData.taxId = exisPref.levelone[i].value;
     // rowData.delIcon = imageDiv;
     levelOne.push(rowData);
     }
     // document.getElementById("delIcon").innerHTML = "<img src='../images/delete.png'>";
     exisRow = {'levelone': levelOne};
     function delPref() {

     }
     $j(function($){
     $('#existingPrefs').footable({
     'columns': ExisClm,
     'rows': exisRow.levelone,
     'paging': {
     'enabled': true
     },
     'sorting': {
     'enabled': true
     },
     'editing': {
     'enabled': true,
     'alwaysShow': true,
     'deleteRow': function(row) {
     delPref(row);
     }
     }
     });
     });
     }); */
    const exisPref = {
      'numofpreferences': '11',
      'levelone': [
        {
          'id': '111',
          'value': '123456879',
          'status': 'WARNING',
          'statusdescription': 'One or more NPIs not related to the Tax ID',
          'modifiedby': 'Joshi, Shweta',
          'modifiedon': '03/11/2011',
          'recipients': [],
          'leveltwo': [
            {
              'id': '221',
              'value': '123454599',
              'status': 'WARNING',
              'statusdescription': 'One or more NPIs not related to the Tax ID',
              'modifiedby': 'XYZ',
              'modifiedon': '03/08/2017',
              'recipients': [],
              'levelthree': [
                {
                  'id': '331',
                  'value': '123454580',
                  'status': 'ONHOLD',
                  'statusdescription': 'Tax ID not found in Organization',
                  'modifiedby': 'XYZ',
                  'modifiedon': '03/08/2017',
                  'recipients': [
                    {
                      'id': '101',
                      'name': 'ABC',
                      'userid': 'avabcuser',
                      'akaname': 'akaABC',
                      'email': 'abc@anthem.com',
                      'mobileno': '1234567890',
                      'status': 'OK',
                      'statusdescription': 'OK'
                    }
                  ]
                }, {
                  'id': '332',
                  'value': '123454581',
                  'status': 'OK',
                  'statusdescription': 'OK',
                  'modifiedby': 'Datar, Pranav',
                  'modifiedon': '03/08/2017',
                  'recipients': [
                    {
                      'id': '102',
                      'name': 'XYZ',
                      'userid': 'avXYZuser',
                      'akaname': 'akaXYZ',
                      'email': 'xyz@anthem.com',
                      'mobileno': '1234567890',
                      'status': 'ONHOLD',
                      'statusdescription': 'Email has changed'
                    }
                  ]
                }
              ]
            }, {
              'id': '222',
              'value': '123454580',
              'status': 'ONHOLD',
              'statusdescription': 'Tax ID not found in Organization',
              'modifiedby': 'Rath, Sushant',
              'modifiedon': '03/08/2017',
              'recipients': [],
              'levelthree': [
                {
                  'id': '333',
                  'value': '123454588',
                  'status': 'ONHOLD',
                  'statusdescription': 'Tax ID not found in Organization',
                  'modifiedby': 'XYZ',
                  'modifiedon': '03/08/2017',
                  'recipients': [
                    {
                      'id': '101',
                      'name': 'ABC',
                      'userid': 'avabcuser',
                      'akaname': 'akaABC',
                      'email': 'abc@anthem.com',
                      'mobileno': '1234567890',
                      'status': 'OK',
                      'statusdescription': 'OK'
                    }
                  ]
                }, {
                  'id': '334',
                  'value': '123454589',
                  'status': 'OK',
                  'statusdescription': 'OK',
                  'modifiedby': 'Dubey, Pooja',
                  'modifiedon': '03/08/2017',
                  'recipients': [
                    {
                      'id': '102',
                      'name': 'XYZ',
                      'userid': 'avXYZuser',
                      'akaname': 'akaXYZ',
                      'email': 'xyz@anthem.com',
                      'mobileno': '1234567890',
                      'status': 'ONHOLD',
                      'statusdescription': 'Email has changed'
                    }
                  ]
                }
              ]
            }
          ]
        }, {
          'id': '112',
          'value': '123456880',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Swamy, Prashant',
          'modifiedon': '03/11/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '114',
          'value': '123456881',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Dubey, Pooja',
          'modifiedon': '03/11/2014',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '112',
          'value': '123456882',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Datar, Pranav',
          'modifiedon': '09/13/2016',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '112',
          'value': '123456883',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Jogdand, Arpita',
          'modifiedon': '09/30/2017',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456888',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Monique, parker',
          'modifiedon': '04/12/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456889',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Christine, Andrews',
          'modifiedon': '04/21/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456890',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Griesbaum, Michael',
          'modifiedon': '01/01/2010',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456891',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Potter, Harry',
          'modifiedon': '05/12/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456892',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Tendulkar, Sachin',
          'modifiedon': '04/15/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456893',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Kalam, Abdul',
          'modifiedon': '04/13/2015',
          'recipients': [],
          'leveltwo': []
        }
      ]
    };

    const $j = jQuery.noConflict();
    // let a= $('.footable tbody tr').length;
    /* eslint-disable */
    if (FooTable.get('#existingPrefs') !== undefined && FooTable.get('#existingPrefs') !== null) {
      const rowcnt = FooTable.get('#existingPrefs').rows.all.length;
      if (rowcnt > 0) {
        FooTable.get('#existingPrefs').destroy();
      }
    }
    /* eslint-enable */
    let exisRow = [];
    const rowCount = exisPref.levelone.length;
    const levelOne = [];
    let i = 0;
    const imageDiv = document.createElement('span');
    const expandDIv = document.createElement('a');
    expandDIv.setAttribute('data-toggle', 'collapse');
    imageDiv.setAttribute('class', 'icon icon-trash-empty');
    this.isExistingPref = true;
    this.numOfExPref = exisPref.numofpreferences;
    for (i = 0; i < rowCount; i++) {
      const rowData = {};
      rowData.modifiedBy = exisPref.levelone[i].modifiedby;
      rowData.modifiedOn = moment(new Date(exisPref.levelone[i].modifiedon)).format('L');
      rowData.taxId = exisPref.levelone[i].value;
      // rowData.details = 11;
      // $j('#existingPrefs.details').appendChild(expandDIv);
      // rowData.delIcon = imageDiv;
      levelOne.push(rowData);
    }
    exisRow = {'levelone': levelOne};
    function delPref() {

    }
    $j(function($){
      $('#existingPrefs').footable({
        'columns': ExisClm,
        'rows': exisRow.levelone,
        'paging': {
          'enabled': true
        },
        'sorting': {
          'enabled': true
        },
        'editing': {
          'enabled': true,
          'alwaysShow': true,
          'filterable': false,
          'sortable': false,
          'data-sorting': false,
          'deleteRow': function(row) {
            delPref(row);
          }
        }
      });
    });
  }
}

app
  .addModules([
    availity,
    uiRouter
  ])
  .service('dashboard', Dashboard);

export default app;
