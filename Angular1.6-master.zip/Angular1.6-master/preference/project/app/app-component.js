import app from 'app-module';

import template from './app.htm';

app.component('app', { template });
