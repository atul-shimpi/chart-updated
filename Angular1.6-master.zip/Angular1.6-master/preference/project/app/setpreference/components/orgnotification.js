import template from './orgnotification.htm';

const orgnotification = {
  replace: true,
  template
};

export default function() {
  return orgnotification;
}
