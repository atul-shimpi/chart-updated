import template from './tax.htm';

const tax = {
  replace: true,
  template
};

export default function() {
  return tax;
}
