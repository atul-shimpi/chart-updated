import app from 'app-module';
import orgnotification from './orgnotification';
import tax from './tax';
import recipients from './recipients';
app
	.directive('orgnotificationSection', orgnotification)
	.directive('taxSection', tax)
  .directive('recipientsSection', recipients);
export default app;
