/**
 * Created by AF03652 on 5/12/2017.
 */
import template from './recipients.htm';
import '../../fooTable/FooTable-3/compiled/footable.bootstrap.min.css';
import '../../fooTable/FooTable-3/compiled/footable.core';
import '../../fooTable/FooTable-3/compiled/footable.sorting';
import '../../fooTable/FooTable-3/compiled/footable.filtering';
import '../../fooTable/FooTable-3/compiled/footable.paging';
import '../../fooTable/FooTable-3/compiled/footable.editing';

const recipients = {
  replace: true,
  template
};

export default function() {
  return recipients;
}

