import uiRouter from 'angular-ui-router';
import { availity } from 'availity-angular';
import app from 'app-module';

import SetPreferenceController from './controller';
import { request } from '../validation';
import body from './body.htm';
import './components';
import { footer, header } from '../common';

// import { brandConstants } from './contants/constants';
const config = function($stateProvider, avValProvider) {

  $stateProvider
    .state('app.setpreference', {
      url: '^/setpreference',
      data: {
        title: 'Preference Center'
      },
      views: {
        'header': {
          template: header,
          controller($state) {
            this.title = $state.current.data.title;

          },
          controllerAs: 'vm'
        },
        'body': {
          template: body,
          controller: SetPreferenceController,
          controllerAs: 'vm'
        },
        'footer': {
          template: footer
        }
      }
    });

  avValProvider.addRules({
    request
  });

};

app
  .addModules([uiRouter, availity])
  .config(config);

export default app;
