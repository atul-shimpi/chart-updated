import './setpreference';

class SetPreferenceController {

  constructor(setpreference) {

    const vm = this;
    setpreference.init();
    vm.setpreference = setpreference;

  }

}

export default SetPreferenceController;


