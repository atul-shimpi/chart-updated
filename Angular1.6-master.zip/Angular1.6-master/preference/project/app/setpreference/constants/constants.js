/**
 * Created by AF03649 on 4/7/2017.
 */
/* export const brandConstants = {
  "IN": {
      "73162546201446435076352200000165":{
        "code": "UNICARE",
          "name": "UNICARE",
          "logoURL": "./images/Unicare.png"
      },
      "isMultiBrand": true,
        "default": {
        "code": "ABCBS",
          "name": "Anthem",
          "logoURL": "./images/ABCBS.png"
      }
}
} */

