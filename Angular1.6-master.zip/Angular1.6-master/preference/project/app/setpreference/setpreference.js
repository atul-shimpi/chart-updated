import app from 'app-module';
import { availity } from 'availity-angular';
import uiRouter from 'angular-ui-router';
import * as $ from 'jquery';
import '../common/apis/api-existing-pref';
import jQuery from 'jquery';
import recipCol from './recpientConfig/footable_Columns.json';

class SetPreference {

  constructor(dashboard, $state) {
    this.di = {dashboard, $state};
    this.selectedOrganization = null;
    this.selectedNotificationType = null;
    this.showRecipients = false;
    // this is mock data this will be replaced by service calls
    if (this.di.dashboard.taxIds.length > 0) {
      this.taxIds = this.di.dashboard.taxIds;
    } else {
      // this is for temporary purpose.
      this.taxIds = [123456879, 123456780, 123456879, 123456781, 123456872, 123456783, 123456874, 123456785, 123456876, 123456787];
    }

    // this.taxId = null;
    // this.npiRowArray = [{'npi0': '', 'npi1': '', 'npi2': '', 'npi3': '', 'npi4': '', 'isTopButton': true}];

  }

  init() {
    this.selectedOrganization = this.di.dashboard.selectedOrganization;
    this.selectedNotificationType = this.di.dashboard.selectedPrefType.name;
    this.taxId = null;
    // this.taxIds = this.di.dashboard.taxIds;
    this.npiRowArray = [{'npi0': '', 'npi1': '', 'npi2': '', 'npi3': '', 'npi4': '', 'isTopButton': true}];

  }

  onKeyUp(index, secondIndex, requestForm){
    const element = document.getElementById('npi' + index + '_' + (secondIndex));
    const nextElement = document.getElementById('npi' + index + '_' + (secondIndex + 1));
    // console.log('Hi '+requestForm.$valid);
    if (requestForm.$valid) {
      if (element.value) {
        element.style.borderColor = '#ccc';
        element.style.backgroundColor = '#fff';
        nextElement.disabled = false;
        // console.log('inside valid and if loop');
        nextElement.focus();
      } else {
        // console.log('inside valid and else loop');
        element.style.borderColor = '#ccc';
        element.style.backgroundColor = '#fff';
      }

    } else {
      // console.log('inside else');
      element.style.borderColor = '#931b1d';
      element.style.backgroundColor = '#fbcbc8';
    }
  }
  isContinueEnabled(requestForm){
   // check if atleast one valid npi is entered
    let isAtleastOneNPIPresent = false;
    for (let i = 0; i < this.npiRowArray.length; i++) {
      const isAtleastOneNPIPresentInRow = this.npiRowArray[i].npi0 || this.npiRowArray[i].npi1 || this.npiRowArray[i].npi2 || this.npiRowArray[i].npi3
      || this.npiRowArray[i].npi4;
      isAtleastOneNPIPresent = isAtleastOneNPIPresent || isAtleastOneNPIPresentInRow;
    }

    // check if taxId is entered
    let isTaxIdPresent = false;
    if (this.taxId){
      isTaxIdPresent = true;
    }

    return requestForm.$valid && isTaxIdPresent && isAtleastOneNPIPresent;
  }
  addNPIRow(){
    for (let i = 0; i < this.npiRowArray.length; i++) {
      this.npiRowArray[i].isTopButton = false;
    }
    if (this.npiRowArray.length < 5) {
      this.npiRowArray.push({'npi0': '', 'npi1': '', 'npi2': '', 'npi3': '', 'npi4': '', 'isTopButton': true});
    } else {
      this.npiRowArray.push({'npi0': '', 'npi1': '', 'npi2': '', 'npi3': '', 'npi4': '', 'isTopButton': false});
    }
    const npiArrayLength = this.npiRowArray.length;
    setTimeout(function(){
      document.getElementById('npi' + (npiArrayLength - 1) + '_' + 0).focus();
    }, 0);

  }

  isAddEnabled(requestForm, index){
    const condition = this.npiRowArray[index].npi0 && this.npiRowArray[index].npi1 && this.npiRowArray[index].npi2
                    && this.npiRowArray[index].npi3 && this.npiRowArray[index].npi4 && this.npiRowArray[index].buttonEnabled;
    if (condition && requestForm.$valid && index < 5) {
      return true;
    }
    return false;
  }

  onPrevious() {
    this.di.$state.go('app.dashboard', {taskTodo: 'continue' }, { location: false });
  }
  onCancel(){
    $('#statusModal').modal('hide');
    $('.body').removeClass('modal-open');
    $('.modal-backdrop').remove();
    this.taxId = null;
    this.npiRowArray = [{'npi0': '', 'npi1': '', 'npi2': '', 'npi3': '', 'npi4': '', 'isTopButton': true}];
    this.di.$state.go('app.dashboard', {taskTodo: 'reset'}, { location: false });
  }

  onContinue(){
    $('#optionsRadios1').prop('checked', true);
    let counter = 0;
    let isMultipleNPIPresent = false;
    for ( let i = 0; i < this.npiRowArray.length; i++){
      for ( const j in this.npiRowArray[i]){
        if (!isNaN(parseFloat(this.npiRowArray[i][j]))) {
          counter++;
        }
        if (counter === 2) {
          isMultipleNPIPresent = true;
          break;
        }
      }
      if (counter === 2) {
        isMultipleNPIPresent = true;
        break;
      }
    }

    if (isMultipleNPIPresent) {
      $('#continueModal').modal();
    }

  }
  populateRecipients(){
    this.showRecipients = true;
    const exisPref = {
      'numofpreferences': '11',
      'levelone': [
        {
          'id': '111',
          'value': '123456879',
          'status': 'WARNING',
          'statusdescription': 'One or more NPIs not related to the Tax ID',
          'modifiedby': 'Joshi, Shweta',
          'modifiedon': '03/11/2011',
          'recipients': [],
          'leveltwo': [
            {
              'id': '221',
              'value': '123454599',
              'status': 'WARNING',
              'statusdescription': 'One or more NPIs not related to the Tax ID',
              'modifiedby': 'XYZ',
              'modifiedon': '03/08/2017',
              'recipients': [],
              'levelthree': [
                {
                  'id': '331',
                  'value': '123454580',
                  'status': 'ONHOLD',
                  'statusdescription': 'Tax ID not found in Organization',
                  'modifiedby': 'XYZ',
                  'modifiedon': '03/08/2017',
                  'recipients': [
                    {
                      'id': '101',
                      'name': 'ABC',
                      'userid': 'avabcuser',
                      'akaname': 'akaABC',
                      'email': 'abc@anthem.com',
                      'mobileno': '1234567890',
                      'status': 'OK',
                      'statusdescription': 'OK'
                    }
                  ]
                }, {
                  'id': '332',
                  'value': '123454581',
                  'status': 'OK',
                  'statusdescription': 'OK',
                  'modifiedby': 'Datar, Pranav',
                  'modifiedon': '03/08/2017',
                  'recipients': [
                    {
                      'id': '102',
                      'name': 'XYZ',
                      'userid': 'avXYZuser',
                      'akaname': 'akaXYZ',
                      'email': 'xyz@anthem.com',
                      'mobileno': '1234567890',
                      'status': 'ONHOLD',
                      'statusdescription': 'Email has changed'
                    }
                  ]
                }
              ]
            }, {
              'id': '222',
              'value': '123454580',
              'status': 'ONHOLD',
              'statusdescription': 'Tax ID not found in Organization',
              'modifiedby': 'Rath, Sushant',
              'modifiedon': '03/08/2017',
              'recipients': [],
              'levelthree': [
                {
                  'id': '333',
                  'value': '123454588',
                  'status': 'ONHOLD',
                  'statusdescription': 'Tax ID not found in Organization',
                  'modifiedby': 'XYZ',
                  'modifiedon': '03/08/2017',
                  'recipients': [
                    {
                      'id': '101',
                      'name': 'ABC',
                      'userid': 'avabcuser',
                      'akaname': 'akaABC',
                      'email': 'abc@anthem.com',
                      'mobileno': '1234567890',
                      'status': 'OK',
                      'statusdescription': 'OK'
                    }
                  ]
                }, {
                  'id': '334',
                  'value': '123454589',
                  'status': 'OK',
                  'statusdescription': 'OK',
                  'modifiedby': 'Dubey, Pooja',
                  'modifiedon': '03/08/2017',
                  'recipients': [
                    {
                      'id': '102',
                      'name': 'XYZ',
                      'userid': 'avXYZuser',
                      'akaname': 'akaXYZ',
                      'email': 'xyz@anthem.com',
                      'mobileno': '1234567890',
                      'status': 'ONHOLD',
                      'statusdescription': 'Email has changed'
                    }
                  ]
                }
              ]
            }
          ]
        }, {
          'id': '112',
          'value': '123456880',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Swamy, Prashant',
          'modifiedon': '03/11/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '114',
          'value': '123456881',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Dubey, Pooja',
          'modifiedon': '03/11/2014',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '112',
          'value': '123456882',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Datar, Pranav',
          'modifiedon': '09/13/2016',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '112',
          'value': '123456883',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Jogdand, Arpita',
          'modifiedon': '09/30/2017',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456888',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Monique, parker',
          'modifiedon': '04/12/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456889',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Christine, Andrews',
          'modifiedon': '04/21/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456890',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Griesbaum, Michael',
          'modifiedon': '01/01/2010',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456891',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Potter, Harry',
          'modifiedon': '05/12/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456892',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Tendulkar, Sachin',
          'modifiedon': '04/15/2015',
          'recipients': [],
          'leveltwo': []
        },
        {
          'id': '113',
          'value': '123456893',
          'status': 'OK',
          'statusdescription': 'OK',
          'modifiedby': 'Kalam, Abdul',
          'modifiedon': '04/13/2015',
          'recipients': [],
          'leveltwo': []
        }
      ]
    };
    const $j = jQuery.noConflict();
    let exisRow = [];
    const rowCount = exisPref.levelone.length;
    const levelOne = [];
    let i = 0;
    for (i = 0; i < rowCount; i++) {
      const rowData = {};
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = true;
      cb.autocomplete = "on";
      rowData.name = exisPref.levelone[i].modifiedby;
      rowData.select = cb;
      levelOne.push(rowData);
    }
    exisRow = {'levelone': levelOne};
    $j(function($s){
      $s('#existingPrefs').footable({
        'columns': recipCol,
        'rows': exisRow.levelone,
        'paging': {
          'enabled': true
        },
        'sorting': {
          'enabled': true
        }
      });
    });
  }

  cancel(){
    $('#continueModal').modal('hide');
  }

  continue(){
    $('#continueModal').modal('hide');
    this.populateRecipients();
  }

  showDetailNPIError(errorText, index){

    const errorId = '#' + errorText + index;
    const existingErrorText = 'Invalid NPI';
    if ($(errorId).text() === existingErrorText) {
      $(errorId).text('Enter a valid NPI containing 10 numeric digits and beginning with a 1, 2, 3, or 4');
    }

  }

  showInvalidNPI(errorText, index){
    const errorId = '#' + errorText + index;
    const existingErrorText = 'Enter a valid NPI containing 10 numeric digits and beginning with a 1, 2, 3, or 4';
    if ($(errorId).text() === existingErrorText) {
      $(errorId).text('Invalid NPI');
    }

  }
}

app
  .addModules([
    availity,
    uiRouter
  ])
  .service('setpreference', SetPreference);

export default app;
