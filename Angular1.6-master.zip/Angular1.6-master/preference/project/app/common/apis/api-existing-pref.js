/**
 * Created by AF03652 on 04/25/17.
 */
import app from 'app-module';
import { availity } from 'availity-angular';

const preferenceResourceFactory = function(AvProxyResource) {

  class PreferenceResource extends AvProxyResource {

    constructor() {
      super({
        tenant: 'healthplan',
        name: '/provconn/v1/prefcenter/preferences'
      });
    }
  }

  return new PreferenceResource();

};

app
  .addModule(availity)
  .factory('preferenceResource', preferenceResourceFactory);

export default app;
