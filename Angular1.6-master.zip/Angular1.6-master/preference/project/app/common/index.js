import footer from './footer.htm';
import header from './header.htm';

export {
  footer,
  header
};
